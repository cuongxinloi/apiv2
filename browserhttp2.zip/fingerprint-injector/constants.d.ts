export declare const UTILS_FILE_NAME = "utils.js";
//# sourceMappingURL=constants.d.ts.map